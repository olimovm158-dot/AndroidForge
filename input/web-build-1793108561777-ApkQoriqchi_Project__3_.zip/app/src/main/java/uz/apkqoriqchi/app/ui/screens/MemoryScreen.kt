package uz.apkqoriqchi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Apk Qo'riqchi - Xotira Tekshiruvi Ekrani
 * Qurilmaning doimiy xotirasi (ROM), operativ xotirasi (RAM) va kesh tozalash.
 */
@Composable
fun MemoryScreen(onBackClick: () -> Unit) {
    var isCleaning by remember { mutableStateOf(false) }
    var cleanedMb by remember { mutableIntStateOf(0) }
    var currentCacheMb by remember { mutableIntStateOf(1840) }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Xotira tekshiruvi", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Orqaga")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Ichki Xotira (ROM)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Doimiy Xotira (ROM)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("128 GB jami", fontSize = 12.sp, color = Color.Gray)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { 0.53f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp)),
                        color = PrimaryOrange,
                        trackColor = Color.LightGray.copy(alpha = 0.3f)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Band: 68.4 GB (53%)", fontSize = 12.sp, color = Color.Gray)
                        Text("Bo'sh: 59.6 GB", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00E676))
                    }
                }
            }

            // Operativ Xotira (RAM)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Operativ Xotira (RAM)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("8.0 GB jami", fontSize = 12.sp, color = Color.Gray)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { 0.51f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp)),
                        color = Color(0xFF00E676),
                        trackColor = Color.LightGray.copy(alpha = 0.3f)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Band: 4.2 GB", fontSize = 12.sp, color = Color.Gray)
                        Text("Bo'sh: 3.8 GB", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00E676))
                    }
                }
            }

            // Kesh va Vaqtinchalik Fayllar
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Keraksiz kesh fayllari", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${currentCacheMb} MB xavfsiz tozalash mumkin",
                        fontSize = 13.sp,
                        color = PrimaryOrange,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (!isCleaning && currentCacheMb > 0) {
                                isCleaning = true
                                scope.launch {
                                    delay(1200)
                                    cleanedMb = currentCacheMb
                                    currentCacheMb = 0
                                    isCleaning = false
                                }
                            }
                        },
                        enabled = !isCleaning && currentCacheMb > 0,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryOrange)
                    ) {
                        Text(
                            text = if (isCleaning) "Tozalanmoqda..." else if (currentCacheMb == 0) "Kesh tozalandi!" else "Keshni tozalash",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
