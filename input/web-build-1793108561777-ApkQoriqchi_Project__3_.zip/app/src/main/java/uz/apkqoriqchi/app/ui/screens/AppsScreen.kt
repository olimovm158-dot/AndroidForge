package uz.apkqoriqchi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class AppSecurityInfo(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val sizeMb: Double,
    val permissions: List<String>,
    val riskLevel: RiskLevel
)

enum class RiskLevel {
    SAFE, SUSPICIOUS, DANGEROUS
}

/**
 * Apk Qo'riqchi - Ilovalar (Apps) Ekrani
 * Qurilmadagi barcha ilovalarni xavfsizlik filtri va ruxsatlar bilan ko'rsatadi.
 */
@Composable
fun AppsScreen(
    onBackClick: () -> Unit,
    onAppSelect: (AppSecurityInfo) -> Unit = {}
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("Barchasi") }

    val sampleApps = remember {
        listOf(
            AppSecurityInfo("Telegram", "org.telegram.messenger", "10.9.1", 58.4, listOf("Kamera", "Xotira", "Mikrofon"), RiskLevel.SAFE),
            AppSecurityInfo("Payme", "uz.dida.payme", "3.2.0", 42.1, listOf("Kamera", "Internet", "Biometriya"), RiskLevel.SAFE),
            AppSecurityInfo("Click Up", "uz.click.app", "4.1.2", 39.5, listOf("Kamera", "SMS", "Internet"), RiskLevel.SAFE),
            AppSecurityInfo("Kun.uz", "uz.kun.news", "2.4.0", 18.2, listOf("Internet", "Bildirishnomalar"), RiskLevel.SAFE),
            AppSecurityInfo("MyGovUz", "uz.egov.mygov", "1.8.5", 26.8, listOf("Internet", "Biometriya"), RiskLevel.SAFE),
            AppSecurityInfo("Yandex Go", "ru.yandex.taxi", "5.12.0", 84.0, listOf("Joylashuv", "Xotira", "Internet"), RiskLevel.SAFE),
            AppSecurityInfo("YouTube", "com.google.android.youtube", "19.12.3", 112.5, listOf("Internet", "Xotira"), RiskLevel.SAFE),
            AppSecurityInfo("Uzum Market", "uz.uzum.market", "2.0.1", 55.3, listOf("Joylashuv", "Internet"), RiskLevel.SAFE),
            AppSecurityInfo("Milliy Bank", "uz.nbu.mobile", "3.0.4", 48.0, listOf("SMS", "Internet", "Biometriya"), RiskLevel.SAFE)
        )
    }

    val filteredApps = sampleApps.filter { app ->
        val matchesQuery = app.appName.contains(searchQuery, ignoreCase = true) ||
                app.packageName.contains(searchQuery, ignoreCase = true)
        val matchesFilter = when (selectedFilter) {
            "Xavfsiz" -> app.riskLevel == RiskLevel.SAFE
            "Shubhali" -> app.riskLevel == RiskLevel.SUSPICIOUS
            "Xavfli" -> app.riskLevel == RiskLevel.DANGEROUS
            else -> true
        }
        matchesQuery && matchesFilter
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("O'rnatilgan ilovalar", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Orqaga")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // Qidiruv maydoni
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Ilovalarni qidirish...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                shape = RoundedCornerShape(16.dp),
                singleLine = true
            )

            // Filtr tugmalari
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Barchasi (42)", "Xavfsiz (42)", "Shubhali (0)", "Xavfli (0)").forEach { tag ->
                    val cleanTag = tag.substringBefore(" (")
                    FilterChip(
                        selected = selectedFilter == cleanTag,
                        onClick = { selectedFilter = cleanTag },
                        label = { Text(tag, fontSize = 11.sp) }
                    )
                }
            }

            // Ilovalar ro'yxati
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(filteredApps) { app ->
                    AppListItemCard(app = app, onClick = { onAppSelect(app) })
                }
            }
        }
    }
}

@Composable
fun AppListItemCard(app: AppSecurityInfo, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(PrimaryOrange.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = app.appName.take(1),
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = PrimaryOrange
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(text = app.appName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(text = app.packageName, fontSize = 11.sp, color = Color.Gray)
                Text(text = "Versiya ${app.versionName} • ${app.sizeMb} MB", fontSize = 10.sp, color = Color.Gray)
            }

            Surface(
                color = when (app.riskLevel) {
                    RiskLevel.SAFE -> Color(0xFFE8F5E9)
                    RiskLevel.SUSPICIOUS -> Color(0xFFFFF3E0)
                    RiskLevel.DANGEROUS -> Color(0xFFFFEBEE)
                },
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = when (app.riskLevel) {
                        RiskLevel.SAFE -> "Xavfsiz"
                        RiskLevel.SUSPICIOUS -> "Shubhali"
                        RiskLevel.DANGEROUS -> "Xavfli"
                    },
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = when (app.riskLevel) {
                        RiskLevel.SAFE -> Color(0xFF2E7D32)
                        RiskLevel.SUSPICIOUS -> Color(0xFFFB8C00)
                        RiskLevel.DANGEROUS -> Color(0xFFE53935)
                    }
                )
            }
        }
    }
}
