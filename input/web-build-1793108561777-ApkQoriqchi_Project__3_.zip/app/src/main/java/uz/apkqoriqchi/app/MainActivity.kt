package uz.apkqoriqchi.app

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import uz.apkqoriqchi.app.ui.screens.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            var currentScreen by remember { mutableStateOf("home") }
            var isDarkTheme by remember { mutableStateOf(false) }

            val colorScheme = if (isDarkTheme) {
                darkColorScheme(
                    primary = Color(0xFFFF9800),
                    secondary = Color(0xFF00E676),
                    background = Color(0xFF121212),
                    surface = Color(0xFF1E1E1E)
                )
            } else {
                lightColorScheme(
                    primary = Color(0xFFFF9800),
                    secondary = Color(0xFF00E676),
                    background = Color(0xFFFAF8F5),
                    surface = Color(0xFFFFFFFF)
                )
            }

            MaterialTheme(colorScheme = colorScheme) {
                when (currentScreen) {
                    "home" -> SecurityDashboardScreen(
                        isDarkTheme = isDarkTheme,
                        useUzbekText = true,
                        onScanClick = { currentScreen = "scan" },
                        onAppsClick = { currentScreen = "apps" },
                        onMemoryClick = { currentScreen = "memory" },
                        onSettingsClick = { currentScreen = "settings" }
                    )
                    "apps" -> AppsScreen(
                        onBackClick = { currentScreen = "home" }
                    )
                    "scan" -> ScanScreen(
                        onBackClick = { currentScreen = "home" }
                    )
                    "memory" -> MemoryScreen(
                        onBackClick = { currentScreen = "home" }
                    )
                    "settings" -> SettingsScreen(
                        onBackClick = { currentScreen = "home" },
                        isDarkTheme = isDarkTheme,
                        onToggleDarkTheme = { isDarkTheme = it }
                    )
                }
            }
        }
    }
}
