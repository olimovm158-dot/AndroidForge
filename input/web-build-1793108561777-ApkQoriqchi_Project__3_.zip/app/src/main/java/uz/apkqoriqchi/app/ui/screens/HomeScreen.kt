package uz.apkqoriqchi.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ==========================================
// RANG KODLARI (Screenshot Color Palette)
// ==========================================
val PrimaryOrange = Color(0xFFFF9800)
val DarkOrange = Color(0xFFF57C00)
val PrimaryGreen = Color(0xFF00E676)
val SafeGreenText = Color(0xFF2E7D32)
val LightGreenGlow = Color(0xFFE8F5E9)

// Metrik kartalar ranglari
val DangerousBg = Color(0xFFFFEBEE)
val DangerousFg = Color(0xFFE53935)
val SuspiciousBg = Color(0xFFFFF3E0)
val SuspiciousFg = Color(0xFFFB8C00)
val SafeBg = Color(0xFFE8F5E9)
val SafeFg = Color(0xFF43A047)

/**
 * Apk Qo'riqchi - Asosiy Xavfsizlik Paneli (Home Screen)
 * Skrinshotga 1:1 mos dizayn va 100% o'zbek tilida.
 */
@Composable
fun SecurityDashboardScreen(
    isDarkTheme: Boolean = false,
    useUzbekText: Boolean = true,
    onScanClick: () -> Unit = {},
    onSettingsClick: () -> Unit = {},
    onAppsClick: () -> Unit = {},
    onMemoryClick: () -> Unit = {}
) {
    var isScanning by remember { mutableStateOf(false) }
    var scanProgress by remember { mutableFloatStateOf(1.0f) }
    val coroutineScope = rememberCoroutineScope()

    val screenBg = if (isDarkTheme) Color(0xFF121212) else Color(0xFFFAF8F5)
    val cardBg = if (isDarkTheme) Color(0xFF1E1E1E) else Color(0xFFFFFFFF)
    val primaryTextColor = if (isDarkTheme) Color(0xFFFFFFFF) else Color(0xFF111827)
    val secondaryTextColor = if (isDarkTheme) Color(0xFF9E9E9E) else Color(0xFF6B7280)

    val animatedProgress by animateFloatAsState(
        targetValue = scanProgress,
        animationSpec = tween(
            durationMillis = if (isScanning) 1800 else 600,
            easing = FastOutSlowInEasing
        ),
        label = "ScanProgress"
    )

    fun startScan() {
        if (isScanning) return
        isScanning = true
        scanProgress = 0f
        coroutineScope.launch {
            delay(100)
            scanProgress = 1.0f
            delay(1900)
            isScanning = false
            onScanClick()
        }
    }

    Scaffold(
        containerColor = screenBg,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = buildAnnotatedString {
                            withStyle(SpanStyle(color = primaryTextColor, fontWeight = FontWeight.Bold, fontSize = 22.sp)) {
                                append("Apk ")
                            }
                            withStyle(SpanStyle(color = PrimaryOrange, fontWeight = FontWeight.Bold, fontSize = 22.sp)) {
                                append("Qo'riqchi")
                            }
                        }
                    )
                },
                actions = {
                    IconButton(onClick = onSettingsClick) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = if (useUzbekText) "Sozlamalar" else "Settings",
                            tint = secondaryTextColor,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = screenBg)
            )
        },
        bottomBar = {
            SecurityBottomNavigation(
                isDarkTheme = isDarkTheme,
                useUzbekText = useUzbekText,
                onAppsClick = onAppsClick,
                onScanClick = { startScan() },
                onMemoryClick = onMemoryClick
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // 1. MARKAZIY YASHIL NUR TARATUVCHI PROGRESS DOIRASI
            CircularSecurityIndicator(
                progress = animatedProgress,
                isScanning = isScanning,
                isDarkTheme = isDarkTheme,
                useUzbekText = useUzbekText,
                modifier = Modifier
                    .size(240.dp)
                    .padding(8.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 2. QURILMA XAVFSIZLIGI STATUS KARTASI
            DeviceSecurityCard(
                safeAppsCount = 42,
                dangerousCount = 0,
                suspiciousCount = 0,
                isDarkTheme = isDarkTheme,
                useUzbekText = useUzbekText,
                cardBg = cardBg,
                primaryTextColor = primaryTextColor,
                secondaryTextColor = secondaryTextColor
            )

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun CircularSecurityIndicator(
    progress: Float,
    isScanning: Boolean,
    isDarkTheme: Boolean,
    useUzbekText: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 10.dp.toPx()
            val radius = (size.minDimension - strokeWidth) / 2

            // Orqa fon aylanasi
            drawCircle(
                color = if (isDarkTheme) Color(0xFF1B2E23) else Color(0xFFE8F5E9).copy(alpha = 0.5f),
                radius = radius
            )

            // Yashil neon progress linyasi
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(
                        Color(0xFF69F0AE),
                        Color(0xFF00E676),
                        Color(0xFF00C853),
                        Color(0xFF69F0AE)
                    )
                ),
                startAngle = -90f,
                sweepAngle = 360f * progress,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Apelsin rangli qalqon nishoni
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(PrimaryOrange.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = PrimaryOrange,
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isScanning) {
                    if (useUzbekText) "Tahlil qilinmoqda..." else "Scanning..."
                } else {
                    if (useUzbekText) "Xavfsizlik tahlili" else "Security Analysis"
                },
                fontSize = 14.sp,
                color = if (isDarkTheme) Color.White else Color(0xFF424242),
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "${(progress * 100).toInt()}%",
                fontSize = 34.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (isDarkTheme) Color(0xFF00E676) else Color(0xFF1B5E20)
            )
        }
    }
}

@Composable
fun DeviceSecurityCard(
    safeAppsCount: Int,
    dangerousCount: Int,
    suspiciousCount: Int,
    isDarkTheme: Boolean,
    useUzbekText: Boolean,
    cardBg: Color,
    primaryTextColor: Color,
    secondaryTextColor: Color
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = if (isDarkTheme) 0.dp else 4.dp,
                shape = RoundedCornerShape(26.dp),
                ambientColor = Color.Black.copy(alpha = 0.05f)
            ),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            // Sarlavha: Yashil qalqon + Qurilma xavfsizligi
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(if (isDarkTheme) Color(0xFF14291E) else Color(0xFFE8F5E9)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = Color(0xFF00E676),
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = if (useUzbekText) "Qurilma xavfsizligi" else "Device Security Status",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryTextColor
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00E676))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (useUzbekText) "Xavfsiz" else "All clear",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF00E676)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Xavfsizlik darajasi ko'rsatkichi
            Text(
                text = if (useUzbekText) "Xavfsizlik darajasi" else "Security Score",
                fontSize = 12.sp,
                color = secondaryTextColor,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = if (useUzbekText) "100% Xavfsiz" else "100% Safe",
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (isDarkTheme) Color(0xFF00E676) else Color(0xFF2E7D32)
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = if (useUzbekText) "$safeAppsCount ta nazoratdagi ilova" else "$safeAppsCount monitored app(s)",
                fontSize = 12.sp,
                color = secondaryTextColor
            )

            Spacer(modifier = Modifier.height(18.dp))

            // 3 ta metrik kartochkalar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = if (useUzbekText) "Xavfli" else "Dangerous",
                    count = dangerousCount,
                    icon = Icons.Default.Dangerous,
                    bgColor = if (isDarkTheme) Color(0xFF2A1618) else DangerousBg,
                    fgColor = DangerousFg,
                    isDark = isDarkTheme,
                    modifier = Modifier.weight(1f)
                )

                MetricCard(
                    title = if (useUzbekText) "Shubhali" else "Suspicious",
                    count = suspiciousCount,
                    icon = Icons.Default.Warning,
                    bgColor = if (isDarkTheme) Color(0xFF2C2214) else SuspiciousBg,
                    fgColor = SuspiciousFg,
                    isDark = isDarkTheme,
                    modifier = Modifier.weight(1f)
                )

                MetricCard(
                    title = if (useUzbekText) "Xavfsiz" else "Safe",
                    count = safeAppsCount,
                    icon = Icons.Default.CheckCircle,
                    bgColor = if (isDarkTheme) Color(0xFF14291E) else SafeBg,
                    fgColor = SafeFg,
                    isDark = isDarkTheme,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    count: Int,
    icon: ImageVector,
    bgColor: Color,
    fgColor: Color,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = fgColor,
                modifier = Modifier.size(20.dp)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = count.toString(),
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = fgColor
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = if (isDark) Color(0xFFD1D5DB) else Color(0xFF616161)
            )
        }
    }
}

@Composable
fun SecurityBottomNavigation(
    isDarkTheme: Boolean,
    useUzbekText: Boolean,
    onAppsClick: () -> Unit,
    onScanClick: () -> Unit,
    onMemoryClick: () -> Unit
) {
    val barBg = if (isDarkTheme) Color(0xFF1E1E1E) else Color(0xFFFFFFFF)
    val inactiveColor = if (isDarkTheme) Color(0xFF757575) else Color(0xFF757575)

    Surface(
        color = barBg,
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Chapda: Ilovalar
            BottomNavItem(
                icon = Icons.Default.Apps,
                label = if (useUzbekText) "Ilovalar" else "Apps",
                isSelected = false,
                inactiveColor = inactiveColor,
                onClick = onAppsClick
            )

            // Markazda: Tekshirish (Ko'tarilgan to'q sariq tugma)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.offset(y = (-14).dp)
            ) {
                FloatingActionButton(
                    onClick = onScanClick,
                    containerColor = PrimaryOrange,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier.size(56.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = if (useUzbekText) "Tekshirish" else "Scan",
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = if (useUzbekText) "Tekshirish" else "Scan",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryOrange
                )
            }

            // O'ngda: Xotira tekshiruvi
            BottomNavItem(
                icon = Icons.Default.Storage,
                label = if (useUzbekText) "Xotira tekshiruvi" else "Memory check",
                isSelected = false,
                inactiveColor = inactiveColor,
                onClick = onMemoryClick
            )
        }
    }
}

@Composable
fun BottomNavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    inactiveColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) PrimaryOrange else inactiveColor,
            modifier = Modifier.size(24.dp)
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (isSelected) PrimaryOrange else inactiveColor
        )
    }
}
