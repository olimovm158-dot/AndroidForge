package uz.apkqoriqchi.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * Apk Qo'riqchi - Xavfsizlik Tekshiruvi Ekrani
 * Bosqichma-bosqich haqiqiy xavfsizlik tahlili simulyatsiyasi.
 */
@Composable
fun ScanScreen(onBackClick: () -> Unit) {
    var isScanning by remember { mutableStateOf(false) }
    var currentStep by remember { mutableIntStateOf(0) }
    var scannedCount by remember { mutableIntStateOf(0) }
    var isCompleted by remember { mutableStateOf(false) }

    val steps = listOf(
        "Tizim fayllari va paketlar tahlili",
        "APK fayllarining SHA-256 raqamli imzolarini verifikatsiya qilish",
        "Maxfiy ruxsatlar (Kamera, Xotira, SMS) auditi",
        "Noma'lum manbalardan o'rnatilgan ilovalarni tahlil qilish",
        "Yakuniy xavfsizlik xulosasi shakllantirilmoqda"
    )

    LaunchedEffect(isScanning) {
        if (isScanning) {
            isCompleted = false
            currentStep = 0
            scannedCount = 0
            while (currentStep < steps.size) {
                delay(600)
                currentStep++
                scannedCount += 8
            }
            scannedCount = 42
            isScanning = false
            isCompleted = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Xavfsizlik Tekshiruvi", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Orqaga")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Yuqori radar / holat kartasi
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .background(if (isCompleted) Color(0xFFE8F5E9) else Color(0xFFFFF3E0)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.Shield,
                            contentDescription = null,
                            tint = if (isCompleted) Color(0xFF00E676) else PrimaryOrange,
                            modifier = Modifier.size(54.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = if (isScanning) "Tekshiruv davom etmoqda..." else if (isCompleted) "Tekshiruv yakunlandi!" else "Xavfsizlik auditiga tayyor",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "$scannedCount / 42 ta ilova tekshirildi",
                        fontSize = 13.sp,
                        color = Color.Gray
                    )
                }
            }

            // Bosqichlar ro'yxati
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                steps.forEachIndexed { index, title ->
                    val done = currentStep > index || isCompleted
                    val current = isScanning && currentStep == index

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(
                                    if (done) Color(0xFF00E676)
                                    else if (current) PrimaryOrange
                                    else Color.LightGray.copy(alpha = 0.4f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (done) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            } else {
                                Text("${index + 1}", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Text(
                            text = title,
                            fontSize = 13.sp,
                            fontWeight = if (current) FontWeight.Bold else FontWeight.Normal,
                            color = if (done || current) MaterialTheme.colorScheme.onSurface else Color.Gray
                        )
                    }
                }
            }

            // Tekshiruvni boshlash tugmasi
            Button(
                onClick = { isScanning = true },
                enabled = !isScanning,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryOrange)
            ) {
                Text(
                    text = if (isScanning) "Tekshirilmoqda..." else "Tekshirishni boshlash",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}
