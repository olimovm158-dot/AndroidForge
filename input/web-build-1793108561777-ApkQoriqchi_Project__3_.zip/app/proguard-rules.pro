# Proguard rules
-keep class uz.apkqoriqchi.app.** { *; }
