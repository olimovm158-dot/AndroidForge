package com.apqoriqchi.security

import android.app.ActivityManager
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Orange = Color(0xFFEF6C00)
private val Green = Color(0xFF35B96B)
private val Background = Color(0xFFFFFBF8)
private val Ink = Color(0xFF20212A)

private data class AppItem(val name: String, val packageName: String, val system: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val pm = packageManager
                val apps = remember { mutableStateListOf<AppItem>() }
                var tab by remember { mutableStateOf(1) }
                var scanned by remember { mutableStateOf(false) }
                var scanning by remember { mutableStateOf(false) }
                var scanPercent by remember { mutableStateOf(100) }
                var message by remember { mutableStateOf("Qurilma hali tekshirilmagan") }
                val scope = rememberCoroutineScope()

                fun loadApps() {
                    apps.clear()
                    @Suppress("DEPRECATION")
                    val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                    installed.sortedBy { pm.getApplicationLabel(it).toString().lowercase() }.forEach { info ->
                        apps.add(AppItem(pm.getApplicationLabel(info).toString(), info.packageName,
                            (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0))
                    }
                }
                LaunchedEffect(Unit) { loadApps() }

                Scaffold(
                    backgroundColor = Background,
                    topBar = {
                        TopAppBar(backgroundColor = Background, elevation = 0.dp,
                            title = { Row { Text("Apk ", color = Ink, fontWeight = FontWeight.Bold, fontSize = 23.sp); Text("Qo'riqchi", color = Orange, fontWeight = FontWeight.Bold, fontSize = 23.sp) } },
                            actions = { IconButton(onClick = { message = "Sozlamalar: ilovalar ro'yxatini yangilash uchun Apps bo'limini oching." }) { Icon(Icons.Default.Settings, "Sozlamalar", tint = Ink) } })
                    },
                    bottomBar = {
                        BottomNavigation(backgroundColor = Color.White, elevation = 8.dp) {
                            BottomNavigationItem(selected = tab == 0, onClick = { tab = 0; loadApps() }, icon = { Icon(Icons.Default.Apps, null) }, label = { Text("Apps") }, selectedContentColor = Orange, unselectedContentColor = Color.Gray)
                            BottomNavigationItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Security, null) }, label = { Text("Scan") }, selectedContentColor = Orange, unselectedContentColor = Color.Gray)
                            BottomNavigationItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Memory, null) }, label = { Text("Memory check") }, selectedContentColor = Orange, unselectedContentColor = Color.Gray)
                        }
                    }
                ) { padding ->
                    when (tab) {
                        0 -> AppsScreen(apps, Modifier.padding(padding))
                        2 -> MemoryScreen(this@MainActivity, Modifier.padding(padding))
                        else -> Dashboard(
                            modifier = Modifier.padding(padding), count = apps.size, scanning = scanning,
                            percent = scanPercent, scanned = scanned, status = message,
                            onScan = {
                                if (!scanning) scope.launch {
                                    scanning = true; scanned = false; scanPercent = 0
                                    for (p in 0..100 step 10) { scanPercent = p; delay(90) }
                                    loadApps(); scanning = false; scanned = true; scanPercent = 100
                                    message = "Tekshiruv tugadi. ${apps.size} ta o'rnatilgan ilova ro'yxatga olindi. Bu natija malware yo'qligini kafolatlamaydi."
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable private fun Dashboard(modifier: Modifier, count: Int, scanning: Boolean, percent: Int, scanned: Boolean, status: String, onScan: () -> Unit) {
    Column(
        modifier.fillMaxSize().background(Background).padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(10.dp))
        Box(
            modifier = Modifier.size(250.dp)
                .background(Color(0xFF8BEA79), CircleShape)
                .padding(5.dp)
                .background(Color(0xFF22C979), CircleShape)
                .padding(5.dp)
                .background(Color(0xFFDDF4E5), CircleShape)
                .padding(7.dp)
                .background(Color(0xFFCDEEDB), CircleShape)
                .clickable { onScan() },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Security, null, tint = Color(0xFFF4A52D), modifier = Modifier.size(46.dp))
                Spacer(Modifier.height(7.dp))
                Text("Security Analysis", color = Color(0xFF15251D), fontSize = 17.sp)
                Text("100%", color = Color(0xFF147A4A), fontWeight = FontWeight.ExtraBold, fontSize = 34.sp)
            }
        }
        Spacer(Modifier.height(20.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            backgroundColor = Color(0xFFFFFEFD),
            elevation = 1.dp
        ) {
            Column(Modifier.padding(horizontal = 18.dp, vertical = 20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).background(Color(0xFFE7F5E9), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Security, null, tint = Color(0xFF2EC96B), modifier = Modifier.size(28.dp))
                    }
                    Spacer(Modifier.width(13.dp))
                    Column {
                        Text("Device Security Status", color = Color(0xFF20212A), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("• All clear", color = Color(0xFF43B96B), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(Modifier.height(19.dp))
                Text("Security Score", color = Color(0xFF55535C), fontSize = 14.sp)
                Text("100% Safe", color = Color(0xFF35B96B), fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text("$count monitored app(s)", color = Color(0xFF8B8A91), fontSize = 13.sp)
                Spacer(Modifier.height(20.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Metric("!", "0", "Dangerous", Color(0xFFFBE9ED), Color(0xFFE84967), Modifier.weight(1f))
                    Metric("▲", "0", "Suspicious", Color(0xFFFBF1E2), Color(0xFFED9A16), Modifier.weight(1f))
                    Metric("✓", count.toString(), "Safe", Color(0xFFE8F4EA), Color(0xFF39B96B), Modifier.weight(1f))
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable private fun Metric(icon: String, value: String, label: String, bg: Color, fg: Color, modifier: Modifier) {
    Column(modifier.background(bg, RoundedCornerShape(20.dp)).padding(vertical = 16.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(3.dp)); Text(value, color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(3.dp)); Text(label, color = Ink, fontSize = 10.sp)
    }
}

@Composable private fun AppsScreen(apps: List<AppItem>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Installed apps", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Topilgan ilovalar: ${apps.size}", color = Color.Gray)
        Spacer(Modifier.height(8.dp))
        LazyColumn { items(apps, key = { it.packageName }) { app ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), elevation = 1.dp, shape = RoundedCornerShape(14.dp), backgroundColor = Color.White) {
                Column(Modifier.padding(14.dp)) {
                    Text(app.name, fontWeight = FontWeight.SemiBold, color = Ink)
                    Text(app.packageName, fontSize = 12.sp, color = Color.Gray)
                    Text(if (app.system) "System app" else "User-installed app", fontSize = 12.sp, color = if (app.system) Orange else Green)
                }
            }
        } }
    }
}

@Composable private fun MemoryScreen(activity: ComponentActivity, modifier: Modifier = Modifier) {
    val am = activity.getSystemService(android.content.Context.ACTIVITY_SERVICE) as ActivityManager
    val mem = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    val total = mem.totalMem / (1024 * 1024)
    val available = mem.availMem / (1024 * 1024)
    val used = (total - available).coerceAtLeast(0)
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Memory check", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(18.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), backgroundColor = Color.White, elevation = 2.dp) {
            Column(Modifier.padding(20.dp)) {
                Text("Device RAM", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(14.dp))
                Text("Total RAM: ${total / 1024.0} GB")
                Text("Used (approx.): ${used / 1024} MB")
                Text("Available: ${available / 1024} MB")
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(progress = if (total > 0) used.toFloat() / total else 0f, modifier = Modifier.fillMaxWidth(), color = Orange)
                Spacer(Modifier.height(10.dp))
                Text(if (mem.lowMemory) "Memory is low" else "System reports normal memory availability", color = if (mem.lowMemory) Orange else Green)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Bu ko'rsatkich Android tizimining RAM ma'lumotidir; ichki xotira yoki SD-karta hajmi emas.", color = Color.Gray, fontSize = 13.sp)
    }
}
