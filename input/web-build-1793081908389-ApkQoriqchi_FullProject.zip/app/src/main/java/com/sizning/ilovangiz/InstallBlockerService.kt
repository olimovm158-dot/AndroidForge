package com.sizning.ilovangiz

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class InstallBlockerService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val packageName = event.packageName?.toString() ?: return

        // Dastur o'rnatuvchi oynasi ochilganda
        if (packageName.contains("packageinstaller") || packageName.contains("installer")) {
            val rootNode = rootInActiveWindow ?: return
            findAndClickCancel(rootNode)
        }
    }

    private fun findAndClickCancel(node: AccessibilityNodeInfo) {
        val cancelTexts = listOf("Cancel", "Bekor qilish", "Отмена", "Yopish", "Close")
        for (text in cancelTexts) {
            val nodes = node.findAccessibilityNodeInfosByText(text)
            for (n in nodes) {
                if (n.isClickable) {
                    n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    return
                }
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                findAndClickCancel(child)
            }
        }
    }

    override fun onInterrupt() {}
}
