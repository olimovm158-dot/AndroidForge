package com.sizning.ilovangiz

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material.MaterialTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                SecurityDashboardScreen(
                    onScanClick = {
                        Toast.makeText(this, "Xavfsizlik skaneri yakunlandi: Barcha ilovalar xavfsiz!", Toast.LENGTH_SHORT).show()
                    },
                    onSettingsClick = {
                        try {
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                            Toast.makeText(this, "Maxsus imkoniyatlar sozlamalaridan 'Apk qoriqchi'ni yoqing", Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            Toast.makeText(this, "Sozlamalarni ochib bo'lmadi", Toast.LENGTH_SHORT).show()
                        }
                    },
                    onAppsClick = {
                        Toast.makeText(this, "Ilovalar ro'yxati: 42 ta ilova nazoratda", Toast.LENGTH_SHORT).show()
                    },
                    onMemoryClick = {
                        Toast.makeText(this, "Xotira holati: 1.8 GB bo'sh", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }
}
