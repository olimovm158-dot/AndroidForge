package com.sizning.ilovangiz

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ==========================================
// RANG KODLARI (Exact Color Palette)
// ==========================================
val PrimaryOrange = Color(0xFFFF9800)
val DarkOrange = Color(0xFFF57C00)
val PrimaryGreen = Color(0xFF4CAF50)
val SafeGreenText = Color(0xFF2E7D32)
val LightGreenGlow = Color(0xFFE8F5E9)

// Metric Cards Colors
val DangerousBg = Color(0xFFFFEBEE)
val DangerousFg = Color(0xFFE53935)

val SuspiciousBg = Color(0xFFFFF3E0)
val SuspiciousFg = Color(0xFFFB8C00)

val SafeBg = Color(0xFFE8F5E9)
val SafeFg = Color(0xFF43A047)

val ScreenBackground = Color(0xFFFAFAFA)
val CardBackground = Color(0xFFFFFFFF)
val MutedText = Color(0xFF9E9E9E)
val DarkText = Color(0xFF212121)

/**
 * Apk Qo'riqchi - Asosiy Xavfsizlik Paneli (Security Dashboard)
 * Material 2 (androidx.compose.material) kutubxonasida yaratilgan.
 */
@Composable
fun SecurityDashboardScreen(
    onScanClick: () -> Unit = {},
    onSettingsClick: () -> Unit = {},
    onAppsClick: () -> Unit = {},
    onMemoryClick: () -> Unit = {}
) {
    var isScanning by remember { mutableStateOf(false) }
    var scanProgress by remember { mutableFloatStateOf(1.0f) }
    val coroutineScope = rememberCoroutineScope()

    // Skanerlash animatsiyasi
    val animatedProgress by animateFloatAsState(
        targetValue = scanProgress,
        animationSpec = tween(durationMillis = if (isScanning) 1800 else 600, easing = FastOutSlowInEasing),
        label = "ProgressAnimation"
    )

    fun startScan() {
        if (isScanning) return
        isScanning = true
        scanProgress = 0f
        coroutineScope.launch {
            delay(100)
            scanProgress = 1.0f
            delay(1900)
            isScanning = false
            onScanClick()
        }
    }

    Scaffold(
        backgroundColor = ScreenBackground,
        topBar = {
            TopAppBar(
                backgroundColor = ScreenBackground,
                elevation = 0.dp,
                title = {
                    Text(
                        text = buildAnnotatedString {
                            withStyle(style = SpanStyle(color = DarkText, fontWeight = FontWeight.Bold, fontSize = 22.sp)) {
                                append("Apk ")
                            }
                            withStyle(style = SpanStyle(color = PrimaryOrange, fontWeight = FontWeight.Bold, fontSize = 22.sp)) {
                                append("Qo'riqchi")
                            }
                        }
                    )
                },
                actions = {
                    IconButton(onClick = onSettingsClick) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Sozlamalar",
                            tint = Color(0xFF757575),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            )
        },
        bottomBar = {
            SecurityBottomNavigation(
                onAppsClick = onAppsClick,
                onScanClick = { startScan() },
                onMemoryClick = onMemoryClick
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // 1. MARKAZIY YASHIL NUR TARATUVCHI PROGRESS DOIRASI
            CircularSecurityIndicator(
                progress = animatedProgress,
                isScanning = isScanning,
                modifier = Modifier
                    .size(240.dp)
                    .padding(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 2. DEVICE SECURITY STATUS OQ KARTASI
            DeviceSecurityCard(
                safeAppsCount = 42,
                dangerousCount = 0,
                suspiciousCount = 0
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

/**
 * Markazdagi Katta Yashil Progress Doirasi (Glow Ring)
 */
@Composable
fun CircularSecurityIndicator(
    progress: Float,
    isScanning: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        // Yumshoq yashil ichki fon nuri
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 12.dp.toPx()
            val radius = (size.minDimension - strokeWidth) / 2

            // Orqa fondagi oqish yashil fon
            drawCircle(
                color = Color(0xFFE8F5E9).copy(alpha = 0.5f),
                radius = radius
            )

            // Yashil progress aylanasi
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(
                        Color(0xFF66BB6A),
                        Color(0xFF4CAF50),
                        Color(0xFF43A047),
                        Color(0xFF66BB6A)
                    )
                ),
                startAngle = -90f,
                sweepAngle = 360f * progress,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }

        // Doira ichidagi kontent
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Apelsin rangli qalqon belgisi
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(PrimaryOrange.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = PrimaryOrange,
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isScanning) "Skanerlanmoqda..." else "Security Analysis",
                fontSize = 14.sp,
                color = Color(0xFF424242),
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "${(progress * 100).toInt()}%",
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF1B5E20)
            )
        }
    }
}

/**
 * Device Security Status Oq Kartasi
 */
@Composable
fun DeviceSecurityCard(
    safeAppsCount: Int,
    dangerousCount: Int,
    suspiciousCount: Int
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 6.dp,
                shape = RoundedCornerShape(24.dp),
                ambientColor = Color.Black.copy(alpha = 0.05f),
                spotColor = Color.Black.copy(alpha = 0.08f)
            ),
        shape = RoundedCornerShape(24.dp),
        backgroundColor = CardBackground,
        elevation = 0.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Yuqori qism: Kichik yashil qalqon + Status + "● All clear"
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE8F5E9)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = PrimaryGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "Device Security Status",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = DarkText
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(PrimaryGreen)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "All clear",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = PrimaryGreen
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // O'rta qism: Security Score, 100% Safe, 42 monitored app(s)
            Text(
                text = "Security Score",
                fontSize = 13.sp,
                color = Color(0xFF616161),
                fontWeight = FontWeight.Normal
            )

            Text(
                text = "100% Safe",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = SafeGreenText,
                modifier = Modifier.padding(vertical = 2.dp)
            )

            Text(
                text = "$safeAppsCount monitored app(s)",
                fontSize = 12.sp,
                color = MutedText
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Pastki qism: 3 ta bir xil kenglikdagi bloklar qatori
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1-blok: Dangerous (Ochiq qizil fon)
                StatusBlock(
                    modifier = Modifier.weight(1f),
                    backgroundColor = DangerousBg,
                    icon = Icons.Default.ErrorOutline,
                    iconColor = DangerousFg,
                    count = dangerousCount.toString(),
                    countColor = DangerousFg,
                    title = "Dangerous"
                )

                // 2-blok: Suspicious (Ochiq apelsin rang fon)
                StatusBlock(
                    modifier = Modifier.weight(1f),
                    backgroundColor = SuspiciousBg,
                    icon = Icons.Default.Warning,
                    iconColor = SuspiciousFg,
                    count = suspiciousCount.toString(),
                    countColor = SuspiciousFg,
                    title = "Suspicious"
                )

                // 3-blok: Safe (Ochiq yashil fon)
                StatusBlock(
                    modifier = Modifier.weight(1f),
                    backgroundColor = SafeBg,
                    icon = Icons.Default.CheckCircle,
                    iconColor = SafeFg,
                    count = safeAppsCount.toString(),
                    countColor = SafeFg,
                    title = "Safe"
                )
            }
        }
    }
}

/**
 * 3 ta blok uchun burchaklari yumaloqlangan universal Composable
 */
@Composable
fun StatusBlock(
    modifier: Modifier = Modifier,
    backgroundColor: Color,
    icon: ImageVector,
    iconColor: Color,
    count: String,
    countColor: Color,
    title: String
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(backgroundColor)
            .padding(vertical = 14.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconColor,
                modifier = Modifier.size(20.dp)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = count,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = countColor
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF616161)
            )
        }
    }
}

/**
 * Pastki Navigatsiya Paneli (Bottom Navigation Bar)
 * Markazda apelsin rangli suzuvchi (floating) Scan tugmasi bilan
 */
@Composable
fun SecurityBottomNavigation(
    onAppsClick: () -> Unit,
    onScanClick: () -> Unit,
    onMemoryClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBackground)
            .padding(vertical = 8.dp, horizontal = 24.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Chapda: Apps (To'rsimon belgi)
            BottomNavItem(
                icon = Icons.Default.GridView,
                label = "Apps",
                isSelected = false,
                onClick = onAppsClick
            )

            // Markazda: Suzuvchi dumaloq apelsin rangli Scan tugmasi
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .offset(y = (-14).dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onScanClick
                    )
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .shadow(8.dp, CircleShape, ambientColor = PrimaryOrange.copy(alpha = 0.4f), spotColor = PrimaryOrange)
                        .clip(CircleShape)
                        .background(PrimaryOrange),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Scan",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Scan",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryOrange
                )
            }

            // O'ngda: Memory check (Server/ro'yxat belgisi)
            BottomNavItem(
                icon = Icons.Default.Dns,
                label = "Memory check",
                isSelected = false,
                onClick = onMemoryClick
            )
        }
    }
}

@Composable
fun BottomNavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) PrimaryOrange else Color(0xFF757575),
            modifier = Modifier.size(24.dp)
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (isSelected) PrimaryOrange else Color(0xFF757575)
        )
    }
}

@Preview(showBackground = true)
@Composable
fun SecurityDashboardPreview() {
    SecurityDashboardScreen()
}
