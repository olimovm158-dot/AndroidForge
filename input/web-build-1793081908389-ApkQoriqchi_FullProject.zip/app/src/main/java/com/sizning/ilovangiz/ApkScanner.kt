package com.sizning.ilovangiz

import android.os.Environment
import android.util.Log
import java.io.File

class ApkScanner {
    fun scanAndDeleteApks() {
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val telegramDir = File(Environment.getExternalStorageDirectory(), "Telegram")
        scanDirectory(downloadsDir)
        scanDirectory(telegramDir)
    }

    private fun scanDirectory(dir: File) {
        if (!dir.exists() || !dir.isDirectory) return
        dir.listFiles()?.forEach { file ->
            if (file.isDirectory) {
                scanDirectory(file)
            } else if (file.name.endsWith(".apk", ignoreCase = true)) {
                Log.d("ApkScanner", "Topilgan APK: ${file.absolutePath}")
            }
        }
    }
}
