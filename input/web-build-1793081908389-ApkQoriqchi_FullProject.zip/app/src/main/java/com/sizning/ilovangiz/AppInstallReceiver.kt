package com.sizning.ilovangiz

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log

class AppInstallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_PACKAGE_ADDED) {
            val packageName = intent.data?.schemeSpecificPart ?: return
            checkAppPermissions(context, packageName)
        }
    }

    private fun checkAppPermissions(context: Context, packageName: String) {
        try {
            val packageInfo = context.packageManager.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
            val permissions = packageInfo.requestedPermissions ?: return
            val riskyPermissions = listOf(
                "android.permission.READ_SMS",
                "android.permission.RECEIVE_SMS",
                "android.permission.READ_CONTACTS"
            )
            var isRisky = false
            permissions.forEach { perm ->
                if (riskyPermissions.contains(perm)) {
                    isRisky = true
                    Log.w("AppChecker", "XAVFLI DASTUR! $packageName $perm ruxsatini oldi")
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
