# Proguard rules
-keep class com.sizning.ilovangiz.** { *; }
